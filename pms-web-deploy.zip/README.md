# PMS Web - Deploy Package

## Instalación en Dokploy

1. Subir este ZIP a Dokploy
2. Configurar variables de entorno necesarias
3. Comando de inicio: `npm ci --omit=dev && npm start`
4. Puerto: 4321

## Variables de entorno requeridas

- NODE_ENV=production
- HOST=0.0.0.0
- PORT=4321

